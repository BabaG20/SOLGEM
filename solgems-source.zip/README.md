# SolGems

App ya Solana inayoonyesha CA (contract addresses) za **trending** na **new pairs** kutoka Dexscreener, pamoja na anti-scam checks (mint & freeze authority kupitia Solana RPC), na links za moja kwa moja kwenda **GMGN**, **Axiom**, na **Dexscreener**.

## Features

- 🔥 Trending & New pairs (Dexscreener API)
- 🛡️ Anti-scam: mint/freeze authority checks, liquidity & market cap filters
- 🔐 Login kwa **username + password** (hakuna email confirm)
- 📊 Sort kwa Market Cap (ndogo→kubwa), Volume, Age
- 💬 **Group Chat** kwa members (links zimezuiwa — token na maandishi tu)
- 📢 Admin dashboard: Announcements, Videos, Market Updates, Push Notifications, Settings
- 👥 Live online count (Supabase Realtime Presence)
- 📱 WhatsApp support button
- 🎨 GMGN-inspired dark theme

## Stack

- **TanStack Start** (React 19 + Vite 7) — SSR + file-based routing
- **Tailwind CSS v4** + shadcn/ui
- **Supabase** (Lovable Cloud) — Auth, Postgres, RLS, Realtime
- **Dexscreener API** + **Solana JSON-RPC**

## Local dev

```bash
bun install
bun run dev
```

App inafungua kwenye `http://localhost:8080`.

## Environment

Tengeneza `.env` kwa Supabase credentials zako:

```
VITE_SUPABASE_URL=...
VITE_SUPABASE_PUBLISHABLE_KEY=...
VITE_SUPABASE_PROJECT_ID=...
```

## Database

Migrations zote zipo `supabase/migrations/`. Endesha kupitia Supabase CLI:

```bash
supabase db push
```

Schema kuu:
- `user_roles` (admin/user) + `has_role()` security definer
- `announcements`, `videos`, `market_updates`, `app_settings`, `notifications`
- `chat_messages` (link-blocking CHECK constraint)
- `app_visits` (visitor tracking)

## Admin

Username **`God20`** anapewa admin role kiotomatiki kupitia trigger. Admin anaweza:
- Kuongeza/futa announcements, videos, market updates
- Kutuma push notifications
- Kubadilisha WhatsApp number na settings nyingine
- Kufuta chat messages

## Build

```bash
bun run build
```

## License

MIT
