import { useEffect, useRef, useState } from "react";
import { Send, Shield, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useIsAdmin } from "@/lib/admin";

interface ChatMessage {
  id: string;
  user_id: string;
  username: string;
  content: string;
  created_at: string;
}

// Block any URL-like content. Solana addresses (base58, 32-44 chars, no dots) pass.
const LINK_RE =
  /(https?:\/\/|www\.|t\.me\b|discord\.gg|bit\.ly|tinyurl|\.(com|net|org|io|xyz|app|co|me|gg|tv|link|site|fun|live)\b)/i;

function containsLink(text: string): boolean {
  return LINK_RE.test(text);
}

export function ChatTab() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [user, setUser] = useState<{ id: string; username: string } | null>(null);
  const [sending, setSending] = useState(false);
  const { isAdmin } = useIsAdmin();
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (data.user) {
        const uname =
          (data.user.user_metadata?.username as string | undefined) ||
          data.user.email?.split("@")[0] ||
          "mtumiaji";
        setUser({ id: data.user.id, username: uname });
      }
    })();
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("chat_messages")
        .select("*")
        .order("created_at", { ascending: true })
        .limit(200);
      if (!cancelled && data) setMessages(data as ChatMessage[]);
    })();
    const channel = supabase
      .channel("chat_messages_feed")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "chat_messages" },
        (payload) => {
          setMessages((prev) => [...prev, payload.new as ChatMessage]);
        },
      )
      .on(
        "postgres_changes",
        { event: "DELETE", schema: "public", table: "chat_messages" },
        (payload) => {
          setMessages((prev) => prev.filter((m) => m.id !== (payload.old as ChatMessage).id));
        },
      )
      .subscribe();
    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function send() {
    const text = input.trim();
    if (!text || !user || sending) return;
    if (containsLink(text)) {
      toast.error("Hairuhusiwi kutuma link. Tuma token au maandishi tu.");
      return;
    }
    setSending(true);
    const { error } = await supabase.from("chat_messages").insert({
      user_id: user.id,
      username: user.username,
      content: text,
    });
    setSending(false);
    if (error) {
      toast.error("Imeshindikana kutuma ujumbe (huenda una link).");
      return;
    }
    setInput("");
  }

  async function remove(id: string) {
    const { error } = await supabase.from("chat_messages").delete().eq("id", id);
    if (error) toast.error("Imeshindikana kufuta");
  }

  return (
    <div className="flex flex-col h-[70vh] rounded-2xl border border-border/60 bg-card/40 backdrop-blur card-glow overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border/60 bg-gradient-to-r from-primary/10 to-accent/10">
        <div>
          <h3 className="font-semibold text-sm">Group Chat ya Members</h3>
          <p className="text-[11px] text-muted-foreground">
            Tuma token au chat tu — <span className="text-destructive font-medium">link hazirohusiwi</span>
          </p>
        </div>
        <Badge variant="outline" className="border-primary/40 text-primary">
          <Shield className="h-3 w-3 mr-1" /> Salama
        </Badge>
      </div>

      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-2">
        {messages.length === 0 && (
          <p className="text-center text-xs text-muted-foreground mt-8">
            Hakuna ujumbe bado. Kuwa wa kwanza kuchat!
          </p>
        )}
        {messages.map((m) => {
          const mine = m.user_id === user?.id;
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div
                className={`group max-w-[80%] rounded-2xl px-3 py-2 text-sm ${
                  mine
                    ? "bg-primary text-primary-foreground rounded-br-sm"
                    : "bg-secondary text-secondary-foreground rounded-bl-sm"
                }`}
              >
                {!mine && (
                  <div className="text-[10px] font-semibold opacity-70 mb-0.5">@{m.username}</div>
                )}
                <div className="break-words whitespace-pre-wrap">{m.content}</div>
                <div className="flex items-center justify-end gap-2 mt-1">
                  <span className="text-[10px] opacity-60">
                    {new Date(m.created_at).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                  {isAdmin && (
                    <button
                      onClick={() => remove(m.id)}
                      className="opacity-0 group-hover:opacity-100 transition"
                      aria-label="Futa"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      <div className="border-t border-border/60 p-3 bg-background/60">
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            placeholder="Andika token address au ujumbe..."
            maxLength={500}
            className="bg-background/80"
          />
          <Button onClick={send} disabled={!input.trim() || sending} size="icon">
            <Send className="h-4 w-4" />
          </Button>
        </div>
        <p className="text-[10px] text-muted-foreground mt-1.5 px-1">
          🚫 Hakuna link · ✅ Token addresses & maandishi tu · Max 500 herufi
        </p>
      </div>
    </div>
  );
}
