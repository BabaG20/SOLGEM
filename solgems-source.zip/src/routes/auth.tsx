import { createFileRoute, redirect, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, TrendingUp } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { signInWithUsername, signUpWithUsername } from "@/lib/auth";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "SolGems — Ingia" },
      { name: "description", content: "Ingia kupata Solana CA mpya na zinazotrend kutoka Dexscreener." },
    ],
  }),
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (data.session) throw redirect({ to: "/dashboard" });
  },
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (username.trim().length < 3) return toast.error("Username iwe na herufi 3+");
    if (password.length < 6) return toast.error("Password iwe na herufi 6+");
    setLoading(true);
    try {
      const fn = mode === "signup" ? signUpWithUsername : signInWithUsername;
      const { error } = await fn(username, password);
      if (error) {
        toast.error(error.message);
        return;
      }
      toast.success(mode === "signup" ? "Akaunti imeundwa" : "Karibu tena");
      navigate({ to: "/dashboard" });
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 flex items-center justify-center gap-2">
          <div className="rounded-lg bg-primary/15 p-2 text-primary">
            <TrendingUp className="h-5 w-5" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight">SolGems</h1>
        </div>
        <p className="mb-6 text-center text-sm text-muted-foreground">
          CA za Solana — trending na new pairs kutoka Dexscreener, zikiwa zimechujwa scam.
        </p>

        <div className="card-glow rounded-2xl bg-card p-6">
          <Tabs value={mode} onValueChange={(v) => setMode(v as "signin" | "signup")}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="signin">Ingia</TabsTrigger>
              <TabsTrigger value="signup">Sajili</TabsTrigger>
            </TabsList>
            <TabsContent value={mode} className="mt-5">
              <form onSubmit={submit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="u">Username</Label>
                  <Input
                    id="u"
                    autoComplete="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="kwa_mfano_satoshi"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="p">Password</Label>
                  <Input
                    id="p"
                    type="password"
                    autoComplete={mode === "signup" ? "new-password" : "current-password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                  />
                </div>
                <Button type="submit" disabled={loading} className="w-full">
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {mode === "signup" ? "Sajili" : "Ingia"}
                </Button>
              </form>
              <p className="mt-4 text-center text-xs text-muted-foreground">
                Hakuna confirmation ya email — username + password tu.
              </p>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </main>
  );
}
