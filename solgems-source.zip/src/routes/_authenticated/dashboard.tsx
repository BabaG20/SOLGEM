import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Bell,
  Copy,
  ExternalLink,
  Flame,
  LogOut,
  Megaphone,
  MessageCircle,
  RefreshCw,
  Shield,
  ShieldAlert,
  Shield as ShieldIcon,
  Sparkles,
  TrendingUp,
  Users,
  Video as VideoIcon,
  MessagesSquare,
} from "lucide-react";
import { ChatTab } from "@/components/ChatTab";

import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import { supabase } from "@/integrations/supabase/client";
import {
  getLatestProfiles,
  getTopBoosts,
  hydratePairs,
  type DsPair,
} from "@/lib/dexscreener";
import { getMintInfos, type MintInfo } from "@/lib/solana-mint";
import { getVisitCount, recordVisit } from "@/lib/visits";
import { useIsAdmin } from "@/lib/admin";
import { useOnlineCount } from "@/lib/presence";
import { buildWhatsappUrl, getSettings } from "@/lib/settings";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "SolGems — Trending & New Pairs" },
      { name: "description", content: "CA za Solana zinazotrend na new pairs, zikiwa zimechujwa scam." },
    ],
  }),
  component: Dashboard,
});

type Mode = "trending" | "new";
type SortKey = "mcap-asc" | "mcap-desc" | "vol-desc" | "age-desc" | "age-asc";

interface Filters {
  minLiquidity: number;
  minMarketCap: number;
  requireMintRevoked: boolean;
  requireFreezeRevoked: boolean;
  minAgeMin: number;
  sort: SortKey;
}

const DEFAULTS: Filters = {
  minLiquidity: 10_000,
  minMarketCap: 1_000,
  requireMintRevoked: true,
  requireFreezeRevoked: true,
  minAgeMin: 0,
  sort: "mcap-asc",
};

function Dashboard() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("trending");
  const [filters, setFilters] = useState<Filters>(DEFAULTS);
  const [username, setUsername] = useState<string>("");
  const [userId, setUserId] = useState<string | null>(null);
  const { isAdmin } = useIsAdmin();

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUsername((data.user?.user_metadata?.username as string) ?? "trader");
      setUserId(data.user?.id ?? null);
    });
    recordVisit().catch(() => {});
  }, []);

  const onlineCount = useOnlineCount(userId);
  const visitsQ = useQuery({
    queryKey: ["app-visits"],
    queryFn: getVisitCount,
    staleTime: 60_000,
    refetchInterval: 120_000,
  });
  const settingsQ = useQuery({ queryKey: ["settings"], queryFn: getSettings });
  const whatsappUrl = settingsQ.data ? buildWhatsappUrl(settingsQ.data) : "#";
  const appName = settingsQ.data?.app_name ?? "SolGems";

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  }

  return (
    <main className="min-h-screen pb-16">
      <header className="sticky top-0 z-20 border-b border-border/60 bg-background/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-2 px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="rounded-lg bg-primary/15 p-1.5 text-primary">
              <TrendingUp className="h-4 w-4" />
            </div>
            <div className="leading-tight">
              <div className="text-sm font-bold">{appName}</div>
              <div className="text-[10px] text-muted-foreground">@{username}</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <NotificationsBell />
            {isAdmin && (
              <Button asChild variant="ghost" size="sm" className="h-8 px-2">
                <Link to="/admin"><ShieldIcon className="h-4 w-4 text-primary" /></Link>
              </Button>
            )}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 rounded-lg border border-success/40 bg-success/10 px-2 py-1 text-[11px] font-semibold text-success hover:bg-success/20"
              aria-label="Wasiliana WhatsApp"
            >
              <MessageCircle className="h-3.5 w-3.5" /> Msaada
            </a>
            <Button variant="ghost" size="sm" onClick={signOut} className="h-8 px-2">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-6xl space-y-5 px-4 pt-5">
        <div className="flex items-center justify-between gap-2 rounded-2xl border border-border/60 bg-card/60 px-4 py-2.5 text-xs">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Users className="h-3.5 w-3.5 text-primary" />
            <span>
              Walio online:{" "}
              <span className="font-mono font-bold text-success">{onlineCount}</span>
            </span>
          </div>
          <div className="text-muted-foreground">
            Jumla:{" "}
            <span className="font-mono font-bold text-foreground">
              {visitsQ.data?.toLocaleString() ?? "…"}
            </span>
          </div>
        </div>

        <AnnouncementsBanner />

        <Tabs defaultValue="tokens" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-card/60 backdrop-blur border border-border/60 p-1 h-auto rounded-xl">
            <TabsTrigger value="tokens" className="data-[state=active]:bg-gradient-to-br data-[state=active]:from-primary/30 data-[state=active]:to-accent/20 data-[state=active]:text-primary rounded-lg text-xs"><Flame className="mr-1 h-3.5 w-3.5" /> Tokens</TabsTrigger>
            <TabsTrigger value="chat" className="data-[state=active]:bg-gradient-to-br data-[state=active]:from-primary/30 data-[state=active]:to-accent/20 data-[state=active]:text-primary rounded-lg text-xs"><MessagesSquare className="mr-1 h-3.5 w-3.5" /> Chat</TabsTrigger>
            <TabsTrigger value="videos" className="data-[state=active]:bg-gradient-to-br data-[state=active]:from-primary/30 data-[state=active]:to-accent/20 data-[state=active]:text-primary rounded-lg text-xs"><VideoIcon className="mr-1 h-3.5 w-3.5" /> Video</TabsTrigger>
            <TabsTrigger value="market" className="data-[state=active]:bg-gradient-to-br data-[state=active]:from-primary/30 data-[state=active]:to-accent/20 data-[state=active]:text-primary rounded-lg text-xs"><TrendingUp className="mr-1 h-3.5 w-3.5" /> Soko</TabsTrigger>
          </TabsList>

          <TabsContent value="tokens" className="mt-4 space-y-5">
            <FiltersBar filters={filters} onChange={setFilters} />
            <Tabs value={mode} onValueChange={(v) => setMode(v as Mode)}>
              <TabsList className="grid w-full grid-cols-2 bg-card/60 border border-border/60 rounded-xl p-1 h-auto">
                <TabsTrigger value="trending" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary rounded-lg"><Flame className="mr-2 h-4 w-4" /> Trending</TabsTrigger>
                <TabsTrigger value="new" className="data-[state=active]:bg-accent/20 data-[state=active]:text-accent rounded-lg"><Sparkles className="mr-2 h-4 w-4" /> New Pairs</TabsTrigger>
              </TabsList>
              <TabsContent value="trending" className="mt-4">
                <TokenFeed mode="trending" filters={filters} />
              </TabsContent>
              <TabsContent value="new" className="mt-4">
                <TokenFeed mode="new" filters={filters} />
              </TabsContent>
            </Tabs>
          </TabsContent>

          <TabsContent value="chat" className="mt-4"><ChatTab /></TabsContent>
          <TabsContent value="videos" className="mt-4"><VideosTab /></TabsContent>
          <TabsContent value="market" className="mt-4"><MarketTab /></TabsContent>
        </Tabs>
      </div>
    </main>
  );
}

function NotificationsBell() {
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["notifications"],
    queryFn: async () =>
      (await supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(20)).data ?? [],
    staleTime: 30_000,
  });
  useEffect(() => {
    const ch = supabase
      .channel("notif")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "notifications" }, (p) => {
        const n = p.new as { title: string; body: string };
        toast.message(n.title, { description: n.body });
        qc.invalidateQueries({ queryKey: ["notifications"] });
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [qc]);
  const items = q.data ?? [];
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative h-8 px-2">
          <Bell className="h-4 w-4" />
          {items.length > 0 && (
            <span className="absolute right-0.5 top-0.5 h-1.5 w-1.5 rounded-full bg-primary" />
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-72 p-2">
        <div className="mb-2 px-2 text-xs font-semibold text-muted-foreground">Notifications</div>
        {items.length === 0 && <p className="px-2 py-3 text-center text-xs text-muted-foreground">Hakuna notifications.</p>}
        <ul className="max-h-80 space-y-1 overflow-y-auto">
          {items.map((n) => (
            <li key={n.id} className="rounded-lg p-2 hover:bg-muted/40">
              <div className="text-xs font-semibold">{n.title}</div>
              <div className="text-[11px] text-muted-foreground">{n.body}</div>
            </li>
          ))}
        </ul>
      </PopoverContent>
    </Popover>
  );
}

function AnnouncementsBanner() {
  const q = useQuery({
    queryKey: ["announcements"],
    queryFn: async () =>
      (await supabase.from("announcements").select("*").eq("active", true).order("created_at", { ascending: false }).limit(3)).data ?? [],
    staleTime: 60_000,
  });
  if (!q.data?.length) return null;
  return (
    <div className="space-y-2">
      {q.data.map((a) => (
        <div key={a.id} className="flex items-start gap-2 rounded-xl border border-primary/30 bg-primary/5 px-3 py-2 text-xs">
          <Megaphone className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
          <div className="min-w-0">
            <div className="font-semibold">{a.title}</div>
            <div className="text-muted-foreground">{a.body}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function VideosTab() {
  const q = useQuery({
    queryKey: ["videos"],
    queryFn: async () => (await supabase.from("videos").select("*").order("created_at", { ascending: false })).data ?? [],
  });
  if (q.isLoading) return <Skeleton className="h-32 w-full rounded-2xl" />;
  if (!q.data?.length) return <p className="card-glow rounded-2xl bg-card p-6 text-center text-sm text-muted-foreground">Hakuna video bado.</p>;
  return (
    <ul className="space-y-3">
      {q.data.map((v) => (
        <li key={v.id} className="card-glow rounded-2xl bg-card p-4">
          <div className="font-semibold">{v.title}</div>
          {v.description && <p className="mt-1 text-xs text-muted-foreground">{v.description}</p>}
          <a href={v.url} target="_blank" rel="noreferrer"
            className="mt-2 inline-flex items-center gap-1 text-xs text-primary hover:underline">
            Fungua video <ExternalLink className="h-3 w-3" />
          </a>
        </li>
      ))}
    </ul>
  );
}

function MarketTab() {
  const q = useQuery({
    queryKey: ["market_updates"],
    queryFn: async () => (await supabase.from("market_updates").select("*").order("created_at", { ascending: false })).data ?? [],
  });
  if (q.isLoading) return <Skeleton className="h-32 w-full rounded-2xl" />;
  if (!q.data?.length) return <p className="card-glow rounded-2xl bg-card p-6 text-center text-sm text-muted-foreground">Hakuna market updates bado.</p>;
  return (
    <ul className="space-y-3">
      {q.data.map((m) => (
        <li key={m.id} className="card-glow rounded-2xl bg-card p-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            <span className="font-semibold">{m.token_symbol ?? "Soko"}</span>
            <span className="ml-auto text-[10px] text-muted-foreground">
              {new Date(m.created_at).toLocaleDateString()}
            </span>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">{m.message}</p>
          {m.link && (
            <a href={m.link} target="_blank" rel="noreferrer"
              className="mt-2 inline-flex items-center gap-1 text-xs text-primary hover:underline">
              Soma zaidi <ExternalLink className="h-3 w-3" />
            </a>
          )}
        </li>
      ))}
    </ul>
  );
}

function FiltersBar({ filters, onChange }: { filters: Filters; onChange: (f: Filters) => void }) {
  return (
    <div className="card-glow rounded-2xl bg-card p-4">
      <div className="mb-3 flex items-center gap-2 text-sm font-semibold">
        <Shield className="h-4 w-4 text-primary" /> Anti-scam filters
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <Label>Min liquidity (USD)</Label>
            <span className="font-mono text-primary">${filters.minLiquidity.toLocaleString()}</span>
          </div>
          <Slider min={0} max={100000} step={1000} value={[filters.minLiquidity]}
            onValueChange={([v]) => onChange({ ...filters, minLiquidity: v ?? 0 })} />
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <Label>Min umri (dakika)</Label>
            <span className="font-mono text-primary">{filters.minAgeMin}m</span>
          </div>
          <Slider min={0} max={1440} step={5} value={[filters.minAgeMin]}
            onValueChange={([v]) => onChange({ ...filters, minAgeMin: v ?? 0 })} />
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <Label>Min market cap (USD)</Label>
            <span className="font-mono text-primary">${filters.minMarketCap.toLocaleString()}</span>
          </div>
          <Slider min={1000} max={5_000_000} step={1000} value={[filters.minMarketCap]}
            onValueChange={([v]) => onChange({ ...filters, minMarketCap: v ?? 1000 })} />
        </div>
        <div className="space-y-2">
          <Label className="text-xs">Panga kwa</Label>
          <Select value={filters.sort} onValueChange={(v) => onChange({ ...filters, sort: v as SortKey })}>
            <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="mcap-asc">Market cap: ndogo → kubwa</SelectItem>
              <SelectItem value="mcap-desc">Market cap: kubwa → ndogo</SelectItem>
              <SelectItem value="vol-desc">Volume 24h: juu</SelectItem>
              <SelectItem value="age-asc">Umri: mpya → kongwe</SelectItem>
              <SelectItem value="age-desc">Umri: kongwe → mpya</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center justify-between rounded-lg bg-muted/40 px-3 py-2">
          <Label htmlFor="mint" className="text-xs">Mint authority revoked</Label>
          <Switch id="mint" checked={filters.requireMintRevoked}
            onCheckedChange={(v) => onChange({ ...filters, requireMintRevoked: v })} />
        </div>
        <div className="flex items-center justify-between rounded-lg bg-muted/40 px-3 py-2">
          <Label htmlFor="freeze" className="text-xs">Freeze authority revoked</Label>
          <Switch id="freeze" checked={filters.requireFreezeRevoked}
            onCheckedChange={(v) => onChange({ ...filters, requireFreezeRevoked: v })} />
        </div>
      </div>
    </div>
  );
}

function TokenFeed({ mode, filters }: { mode: Mode; filters: Filters }) {
  const source = useQuery({
    queryKey: ["src", mode],
    queryFn: async () => {
      if (mode === "trending") {
        const boosts = await getTopBoosts();
        return boosts.filter((b) => b.chainId === "solana" && b.tokenAddress).map((b) => b.tokenAddress);
      }
      const profiles = await getLatestProfiles();
      return profiles.filter((p) => p.chainId === "solana" && p.tokenAddress).map((p) => p.tokenAddress);
    },
    staleTime: 30_000,
    refetchInterval: 60_000,
  });

  const addresses = useMemo(() => Array.from(new Set(source.data ?? [])).slice(0, 60), [source.data]);

  const pairsQ = useQuery({
    queryKey: ["pairs", addresses.join(",")],
    queryFn: () => hydratePairs("solana", addresses),
    enabled: addresses.length > 0,
    staleTime: 30_000,
  });

  const mintQ = useQuery({
    queryKey: ["mints", addresses.join(",")],
    queryFn: () => getMintInfos(addresses),
    enabled: addresses.length > 0,
    staleTime: 5 * 60_000,
  });

  const items = useMemo(() => {
    const pairs = pairsQ.data;
    const mints = mintQ.data;
    if (!pairs) return [];
    const out: { pair: DsPair; mint: MintInfo | null }[] = [];
    for (const addr of addresses) {
      const p = pairs.get(addr);
      if (!p) continue;
      const mint = mints?.get(addr) ?? null;
      const liq = p.liquidity?.usd ?? 0;
      if (liq < filters.minLiquidity) continue;
      const mcap = p.marketCap ?? p.fdv ?? 0;
      if (mcap < filters.minMarketCap) continue;
      const ageMin = p.pairCreatedAt ? (Date.now() - p.pairCreatedAt) / 60000 : 0;
      if (ageMin < filters.minAgeMin) continue;
      if (filters.requireMintRevoked && mint && mint.mintAuthority !== null) continue;
      if (filters.requireFreezeRevoked && mint && mint.freezeAuthority !== null) continue;
      out.push({ pair: p, mint });
    }
    const mc = (p: DsPair) => p.marketCap ?? p.fdv ?? 0;
    switch (filters.sort) {
      case "mcap-asc": out.sort((a, b) => mc(a.pair) - mc(b.pair)); break;
      case "mcap-desc": out.sort((a, b) => mc(b.pair) - mc(a.pair)); break;
      case "vol-desc": out.sort((a, b) => (b.pair.volume?.h24 ?? 0) - (a.pair.volume?.h24 ?? 0)); break;
      case "age-asc": out.sort((a, b) => (b.pair.pairCreatedAt ?? 0) - (a.pair.pairCreatedAt ?? 0)); break;
      case "age-desc": out.sort((a, b) => (a.pair.pairCreatedAt ?? 0) - (b.pair.pairCreatedAt ?? 0)); break;
    }
    return out;
  }, [addresses, pairsQ.data, mintQ.data, filters]);

  const loading = source.isLoading || pairsQ.isLoading;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>
          {loading ? "Inapakia..." : `${items.length} token${items.length === 1 ? "" : "s"}`}
          {mintQ.isLoading && !loading && " · inakagua mint authority..."}
        </span>
        <Button size="sm" variant="ghost" onClick={() => {
          source.refetch(); pairsQ.refetch(); mintQ.refetch();
        }}>
          <RefreshCw className="mr-1 h-3.5 w-3.5" /> Refresh
        </Button>
      </div>
      {loading && (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-28 w-full rounded-2xl" />
          ))}
        </div>
      )}
      {!loading && items.length === 0 && (
        <div className="card-glow rounded-2xl bg-card p-8 text-center text-sm text-muted-foreground">
          Hakuna token zinazokidhi filters zako. Punguza min liquidity au zima ukaguzi wa mint authority.
        </div>
      )}
      {items.map(({ pair, mint }) => (
        <TokenCard key={pair.pairAddress} pair={pair} mint={mint} />
      ))}
    </div>
  );
}

function TokenCard({ pair, mint }: { pair: DsPair; mint: MintInfo | null }) {
  const ca = pair.baseToken.address;
  const change = pair.priceChange?.h24 ?? 0;
  const ageMs = pair.pairCreatedAt ? Date.now() - pair.pairCreatedAt : 0;
  const safe = mint ? mint.mintAuthority === null && mint.freezeAuthority === null : null;

  async function copyCa() {
    try {
      await navigator.clipboard.writeText(ca);
      toast.success("CA imecopiwa");
    } catch {
      toast.error("Imeshindwa kucopy");
    }
  }

  return (
    <article className="card-glow rounded-2xl bg-card p-4">
      <div className="flex items-start gap-3">
        <div className="h-12 w-12 shrink-0 overflow-hidden rounded-xl bg-muted">
          {pair.info?.imageUrl ? (
            <img src={pair.info.imageUrl} alt={pair.baseToken.symbol} className="h-full w-full object-cover" />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-xs font-bold text-muted-foreground">
              {pair.baseToken.symbol?.slice(0, 2)}
            </div>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <h3 className="truncate font-bold">{pair.baseToken.name}</h3>
            <span className="text-xs text-muted-foreground">${pair.baseToken.symbol}</span>
            {safe === true && (
              <Badge variant="secondary" className="border-0 bg-success/15 text-[10px] text-success">
                <Shield className="mr-1 h-3 w-3" /> safe mint
              </Badge>
            )}
            {safe === false && (
              <Badge variant="secondary" className="border-0 bg-warning/15 text-[10px] text-warning">
                <ShieldAlert className="mr-1 h-3 w-3" /> authority hai
              </Badge>
            )}
          </div>
          <div className="mt-1 flex flex-wrap items-baseline gap-x-3 gap-y-0.5 text-xs">
            <span className="font-mono text-sm font-semibold">${formatPrice(pair.priceUsd)}</span>
            <span className={change >= 0 ? "text-pos" : "text-neg"}>
              {change >= 0 ? "+" : ""}{change.toFixed(2)}% 24h
            </span>
            <span className="text-muted-foreground">MC ${formatShort(pair.marketCap ?? pair.fdv)}</span>
            <span className="text-muted-foreground">Liq ${formatShort(pair.liquidity?.usd)}</span>
            <span className="text-muted-foreground">Vol ${formatShort(pair.volume?.h24)}</span>
            <span className="text-muted-foreground">Umri {formatAge(ageMs)}</span>
          </div>
        </div>
      </div>

      <div className="mt-3 flex items-center gap-1.5 rounded-lg bg-muted/40 px-2.5 py-1.5">
        <code className="flex-1 truncate font-mono text-[11px] text-muted-foreground">{ca}</code>
        <Button size="sm" variant="ghost" className="h-7 px-2" onClick={copyCa}>
          <Copy className="h-3.5 w-3.5" />
        </Button>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-1.5">
        <LinkBtn href={`https://gmgn.ai/sol/token/${ca}`} label="GMGN" />
        <LinkBtn href={`https://axiom.trade/t/${ca}`} label="Axiom" />
        <LinkBtn href={pair.url} label="Dex" />
      </div>
    </article>
  );
}

function LinkBtn({ href, label }: { href: string; label: string }) {
  return (
    <a href={href} target="_blank" rel="noopener noreferrer"
      className="inline-flex items-center justify-center gap-1 rounded-lg border border-border/60 bg-background/40 px-2 py-1.5 text-xs font-medium text-foreground transition hover:border-primary/40 hover:bg-primary/10 hover:text-primary">
      {label} <ExternalLink className="h-3 w-3" />
    </a>
  );
}

function formatPrice(p?: string) {
  if (!p) return "—";
  const n = Number(p);
  if (!isFinite(n)) return p;
  if (n >= 1) return n.toFixed(4);
  if (n >= 0.01) return n.toFixed(5);
  return n.toPrecision(4);
}
function formatShort(n?: number) {
  if (n == null) return "—";
  if (n >= 1e9) return (n / 1e9).toFixed(2) + "B";
  if (n >= 1e6) return (n / 1e6).toFixed(2) + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(1) + "K";
  return n.toFixed(0);
}
function formatAge(ms: number) {
  if (!ms) return "—";
  const min = ms / 60000;
  if (min < 60) return `${Math.floor(min)}m`;
  const h = min / 60;
  if (h < 24) return `${h.toFixed(1)}h`;
  const d = h / 24;
  return `${d.toFixed(1)}d`;
}
