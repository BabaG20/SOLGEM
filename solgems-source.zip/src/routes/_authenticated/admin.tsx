import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Bell, Megaphone, Settings, Trash2, TrendingUp, Video } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";

import { supabase } from "@/integrations/supabase/client";
import { useIsAdmin } from "@/lib/admin";
import { getSettings, saveSetting } from "@/lib/settings";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin — SolGems" }] }),
  component: AdminPage,
});

function AdminPage() {
  const { isAdmin, loading } = useIsAdmin();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !isAdmin) {
      toast.error("Huna ruhusa ya admin");
      navigate({ to: "/dashboard" });
    }
  }, [isAdmin, loading, navigate]);

  if (loading || !isAdmin) {
    return (
      <main className="mx-auto max-w-3xl space-y-3 p-4">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-40 w-full" />
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-3xl space-y-4 px-4 py-4 pb-20">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-bold">Admin Dashboard</h1>
        <Button asChild variant="ghost" size="sm">
          <Link to="/dashboard">
            <ArrowLeft className="mr-1 h-4 w-4" /> Rudi
          </Link>
        </Button>
      </div>

      <StatsCard />

      <Tabs defaultValue="ann" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="ann"><Megaphone className="h-4 w-4" /></TabsTrigger>
          <TabsTrigger value="vid"><Video className="h-4 w-4" /></TabsTrigger>
          <TabsTrigger value="mkt"><TrendingUp className="h-4 w-4" /></TabsTrigger>
          <TabsTrigger value="notif"><Bell className="h-4 w-4" /></TabsTrigger>
          <TabsTrigger value="set"><Settings className="h-4 w-4" /></TabsTrigger>
        </TabsList>
        <TabsContent value="ann" className="mt-4"><AnnouncementsAdmin /></TabsContent>
        <TabsContent value="vid" className="mt-4"><VideosAdmin /></TabsContent>
        <TabsContent value="mkt" className="mt-4"><MarketAdmin /></TabsContent>
        <TabsContent value="notif" className="mt-4"><NotificationsAdmin /></TabsContent>
        <TabsContent value="set" className="mt-4"><SettingsAdmin /></TabsContent>
      </Tabs>
    </main>
  );
}

function StatsCard() {
  const q = useQuery({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const [v, a, vid, mkt] = await Promise.all([
        supabase.from("app_visits").select("*", { count: "exact", head: true }),
        supabase.from("announcements").select("*", { count: "exact", head: true }),
        supabase.from("videos").select("*", { count: "exact", head: true }),
        supabase.from("market_updates").select("*", { count: "exact", head: true }),
      ]);
      return {
        visits: v.count ?? 0,
        announcements: a.count ?? 0,
        videos: vid.count ?? 0,
        market: mkt.count ?? 0,
      };
    },
  });
  const s = q.data;
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
      <Stat label="Watumiaji" value={s?.visits} />
      <Stat label="Matangazo" value={s?.announcements} />
      <Stat label="Video" value={s?.videos} />
      <Stat label="Market" value={s?.market} />
    </div>
  );
}

function Stat({ label, value }: { label: string; value?: number }) {
  return (
    <div className="card-glow rounded-xl bg-card p-3">
      <div className="text-[10px] text-muted-foreground">{label}</div>
      <div className="font-mono text-lg font-bold text-primary">
        {value?.toLocaleString() ?? "—"}
      </div>
    </div>
  );
}

function AnnouncementsAdmin() {
  const qc = useQueryClient();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const list = useQuery({
    queryKey: ["adm-ann"],
    queryFn: async () => (await supabase.from("announcements").select("*").order("created_at", { ascending: false })).data ?? [],
  });
  async function add() {
    if (!title || !body) return toast.error("Jaza title na body");
    const { error } = await supabase.from("announcements").insert({ title, body, active: true });
    if (error) return toast.error(error.message);
    setTitle(""); setBody(""); toast.success("Tangazo limeongezwa");
    qc.invalidateQueries({ queryKey: ["adm-ann"] });
    qc.invalidateQueries({ queryKey: ["announcements"] });
  }
  async function del(id: string) {
    await supabase.from("announcements").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["adm-ann"] });
    qc.invalidateQueries({ queryKey: ["announcements"] });
  }
  return (
    <div className="space-y-4">
      <div className="card-glow space-y-2 rounded-xl bg-card p-4">
        <Label>Tangazo jipya</Label>
        <Input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <Textarea placeholder="Maelezo..." value={body} onChange={(e) => setBody(e.target.value)} />
        <Button onClick={add} size="sm">Chapisha</Button>
      </div>
      <ItemList items={list.data ?? []} render={(a) => (
        <>
          <div className="font-semibold">{a.title}</div>
          <div className="text-xs text-muted-foreground">{a.body}</div>
        </>
      )} onDel={del} />
    </div>
  );
}

function VideosAdmin() {
  const qc = useQueryClient();
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [desc, setDesc] = useState("");
  const list = useQuery({
    queryKey: ["adm-vid"],
    queryFn: async () => (await supabase.from("videos").select("*").order("created_at", { ascending: false })).data ?? [],
  });
  async function add() {
    if (!title || !url) return toast.error("Jaza title na url");
    const { error } = await supabase.from("videos").insert({ title, url, description: desc || null });
    if (error) return toast.error(error.message);
    setTitle(""); setUrl(""); setDesc(""); toast.success("Video imeongezwa");
    qc.invalidateQueries({ queryKey: ["adm-vid"] });
    qc.invalidateQueries({ queryKey: ["videos"] });
  }
  async function del(id: string) {
    await supabase.from("videos").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["adm-vid"] });
    qc.invalidateQueries({ queryKey: ["videos"] });
  }
  return (
    <div className="space-y-4">
      <div className="card-glow space-y-2 rounded-xl bg-card p-4">
        <Label>Video mpya</Label>
        <Input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <Input placeholder="YouTube URL au link" value={url} onChange={(e) => setUrl(e.target.value)} />
        <Textarea placeholder="Maelezo (hiari)..." value={desc} onChange={(e) => setDesc(e.target.value)} />
        <Button onClick={add} size="sm">Ongeza</Button>
      </div>
      <ItemList items={list.data ?? []} render={(v) => (
        <>
          <div className="font-semibold">{v.title}</div>
          <a href={v.url} target="_blank" rel="noreferrer" className="break-all text-xs text-primary underline">{v.url}</a>
        </>
      )} onDel={del} />
    </div>
  );
}

function MarketAdmin() {
  const qc = useQueryClient();
  const [sym, setSym] = useState("");
  const [msg, setMsg] = useState("");
  const [link, setLink] = useState("");
  const list = useQuery({
    queryKey: ["adm-mkt"],
    queryFn: async () => (await supabase.from("market_updates").select("*").order("created_at", { ascending: false })).data ?? [],
  });
  async function add() {
    if (!msg) return toast.error("Andika message");
    const { error } = await supabase.from("market_updates").insert({
      token_symbol: sym || null, message: msg, link: link || null,
    });
    if (error) return toast.error(error.message);
    setSym(""); setMsg(""); setLink(""); toast.success("Update imechapishwa");
    qc.invalidateQueries({ queryKey: ["adm-mkt"] });
    qc.invalidateQueries({ queryKey: ["market_updates"] });
  }
  async function del(id: string) {
    await supabase.from("market_updates").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["adm-mkt"] });
    qc.invalidateQueries({ queryKey: ["market_updates"] });
  }
  return (
    <div className="space-y-4">
      <div className="card-glow space-y-2 rounded-xl bg-card p-4">
        <Label>Market update</Label>
        <Input placeholder="Token symbol (mfano SOL)" value={sym} onChange={(e) => setSym(e.target.value)} />
        <Textarea placeholder="Message..." value={msg} onChange={(e) => setMsg(e.target.value)} />
        <Input placeholder="Link (hiari)" value={link} onChange={(e) => setLink(e.target.value)} />
        <Button onClick={add} size="sm">Chapisha</Button>
      </div>
      <ItemList items={list.data ?? []} render={(m) => (
        <>
          <div className="font-semibold">{m.token_symbol ?? "Soko"}</div>
          <div className="text-xs text-muted-foreground">{m.message}</div>
        </>
      )} onDel={del} />
    </div>
  );
}

function NotificationsAdmin() {
  const qc = useQueryClient();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const list = useQuery({
    queryKey: ["adm-notif"],
    queryFn: async () => (await supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(20)).data ?? [],
  });
  async function send() {
    if (!title || !body) return toast.error("Jaza title na body");
    const { error } = await supabase.from("notifications").insert({ title, body });
    if (error) return toast.error(error.message);
    setTitle(""); setBody(""); toast.success("Notification imetumwa kwa watumiaji wote");
    qc.invalidateQueries({ queryKey: ["adm-notif"] });
    qc.invalidateQueries({ queryKey: ["notifications"] });
  }
  async function del(id: string) {
    await supabase.from("notifications").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["adm-notif"] });
    qc.invalidateQueries({ queryKey: ["notifications"] });
  }
  return (
    <div className="space-y-4">
      <div className="card-glow space-y-2 rounded-xl bg-card p-4">
        <Label>Tuma push notification</Label>
        <Input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <Textarea placeholder="Message..." value={body} onChange={(e) => setBody(e.target.value)} />
        <Button onClick={send} size="sm">Tuma kwa wote</Button>
      </div>
      <ItemList items={list.data ?? []} render={(n) => (
        <>
          <div className="font-semibold">{n.title}</div>
          <div className="text-xs text-muted-foreground">{n.body}</div>
        </>
      )} onDel={del} />
    </div>
  );
}

function SettingsAdmin() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["settings"], queryFn: getSettings });
  const [wa, setWa] = useState("");
  const [name, setName] = useState("");
  const [msg, setMsg] = useState("");
  useEffect(() => {
    if (q.data) {
      setWa(q.data.whatsapp_number);
      setName(q.data.app_name);
      setMsg(q.data.support_message);
    }
  }, [q.data]);
  async function save() {
    try {
      await Promise.all([
        saveSetting("whatsapp_number", wa.replace(/[^0-9]/g, "")),
        saveSetting("app_name", name),
        saveSetting("support_message", msg),
      ]);
      toast.success("Imehifadhiwa");
      qc.invalidateQueries({ queryKey: ["settings"] });
    } catch (e) {
      toast.error((e as Error).message);
    }
  }
  return (
    <div className="card-glow space-y-3 rounded-xl bg-card p-4">
      <div className="space-y-1">
        <Label>Jina la app</Label>
        <Input value={name} onChange={(e) => setName(e.target.value)} />
      </div>
      <div className="space-y-1">
        <Label>WhatsApp number (kimataifa, mfano 255617194394)</Label>
        <Input value={wa} onChange={(e) => setWa(e.target.value)} />
        <p className="text-[10px] text-muted-foreground">Namba hii imefichwa kwa watumiaji — wanaona kitufe tu cha "Msaada".</p>
      </div>
      <div className="space-y-1">
        <Label>Default WhatsApp message</Label>
        <Textarea value={msg} onChange={(e) => setMsg(e.target.value)} />
      </div>
      <Button onClick={save} size="sm">Hifadhi</Button>
    </div>
  );
}

interface Item { id: string }
function ItemList<T extends Item>({ items, render, onDel }: { items: T[]; render: (t: T) => React.ReactNode; onDel: (id: string) => void }) {
  if (items.length === 0) return <p className="text-center text-xs text-muted-foreground">Hakuna kitu bado.</p>;
  return (
    <ul className="space-y-2">
      {items.map((it) => (
        <li key={it.id} className="flex items-start gap-2 rounded-xl border border-border/60 bg-card/60 p-3">
          <div className="min-w-0 flex-1">{render(it)}</div>
          <Button size="icon" variant="ghost" className="h-7 w-7 shrink-0" onClick={() => onDel(it.id)}>
            <Trash2 className="h-3.5 w-3.5 text-destructive" />
          </Button>
        </li>
      ))}
    </ul>
  );
}
