
CREATE TABLE public.app_visits (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  visitor_key TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.app_visits TO anon, authenticated;
GRANT ALL ON public.app_visits TO service_role;
ALTER TABLE public.app_visits ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anyone can insert visit" ON public.app_visits FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anyone can read visits" ON public.app_visits FOR SELECT TO anon, authenticated USING (true);
